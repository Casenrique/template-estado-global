export function handleHome(navigate) {
    navigate("/");
  }
  
  export function handleCart(navigate) {
    navigate("/cart");
  }
  
  